#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define max 100

struct nodo {
  char nome[max];
  char cognome[max];
  int matricola;
  char esame[max];
  int voto;
  struct nodo *next;
};


struct nodo *inserisci_elemento(struct nodo *top, char nome[],char cognome[], int matricola, char esame[], int voto){
  struct nodo *p;
    if (top == NULL){
      top = malloc (sizeof(struct nodo));
      strcpy(top->nome,nome);
      strcpy(top->cognome,cognome);
      top->matricola=matricola;
      strcpy(top->esame,esame);
      top->voto=voto;
      top -> next = NULL;
      return;
    }
    p = top;

    while (p -> next != NULL)
      p = p -> next;

    p -> next = malloc(sizeof(struct nodo));
    p = p -> next;
    malloc(sizeof(struct nodo));
    strcpy(p->nome,nome);
    strcpy(p->cognome,cognome);
    p->matricola=matricola;
    strcpy(p->esame,esame);
    p->voto=voto;
    p -> next = NULL;

    return top;
}


struct nodo *elimina_elementi(struct nodo *top){
  struct nodo *prev,*curr;
  curr = top;
  while (curr != NULL && curr -> voto < 18){
    prev = curr;
    curr = curr -> next;
    free(prev);
  }
  top = curr;
  if (top != NULL){
    prev = curr;
    curr = curr -> next;
    while (curr != NULL){
      if (curr -> voto < 18){
        prev -> next = curr -> next;
        free(curr);
        curr = prev -> next;
      }else{
        prev = curr;
        curr = curr -> next;
      }
    }
  }
  return top;
};

void Sorting(struct nodo *top){
  struct nodo *p=top;
  struct nodo *t=p -> next;
  struct nodo *store=top;
  while (p -> next != NULL){
    while (t != NULL){
      if (p->matricola == t -> matricola){
        store = p -> next;
        printf("%s\n", store -> nome);
        p -> next = t;
        t = t -> next;
      }else{
        t = t -> next;
      }
    }
    p = p -> next;
  }
  p -> next = store;
  p = p -> next;
  p -> next = NULL;
}


void stampa_lista(struct nodo *lista){
  struct nodo *p;
  p=lista;
  printf("START->\n ");
  while (p!=NULL){
    printf("%s\t%s\t%d\t%s\t%d\n ",p->cognome,p->nome,p->matricola,p->esame,p->voto);
    p=p->next;
  }
  printf("NULL\n");
}

int main(){
  struct nodo *top;
  int matricola,voto;
  char nome[max],cognome[max],esame[max];
  FILE *fp;
  fp = fopen("file.txt","r");
  fscanf(fp,"%s %s %d %s %d\n",nome,cognome,&matricola,esame,&voto);
  while (!feof(fp)){
    top=inserisci_elemento(top,nome,cognome,matricola,esame,voto);
    fscanf(fp, "%s %s %d %s %d\n",nome,cognome,&matricola,esame,&voto);
  }
  top=inserisci_elemento(top,nome,cognome,matricola,esame,voto);
  printf("lista normale: \n");
  stampa_lista(top);
  printf("Lista con elementi cancellati: \n");
  top = elimina_elementi(top);
  stampa_lista(top);
  printf("\n");
  printf("Lista riordinata: \n");
  Sorting(top);
  stampa_lista(top);
  fclose(fp);
  fp = fopen ("file2.txt","w");
  while (top != NULL){
    fprintf(fp, "%s\t%s\t%d\t%s\t%d\n",top -> nome, top -> cognome, top -> matricola, top -> esame, top -> voto );
    top = top -> next;
  }
  fclose(fp);
  return 0;
}
