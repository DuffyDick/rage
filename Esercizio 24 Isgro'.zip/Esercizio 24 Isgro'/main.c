#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define max 100

struct nodo{
  char nome[max];
  char cognome[max];
  int peso;
  int altezza;
  int eta;
  struct nodo *next;
};

struct nodo *inserisci_elementi(struct nodo *top,char nome[max],char cognome[max],int peso,int altezza,int eta){
  struct nodo *prev, *curr,*new;
  prev = NULL;
  curr = top;
  while (curr != NULL){
    prev = curr;
    curr = curr -> next;
  }
  new = malloc(sizeof(struct nodo));
  strcpy(new -> nome,nome);
  strcpy(new -> cognome,cognome);
  new -> peso = peso;
  new -> altezza = altezza;
  new -> eta = eta;

  if (prev == NULL){
    new -> next = top;
    top = new;
    return top;
  }else{
    prev -> next = new;
    new -> next = curr;
    return top;
  }
}

float calcola_indice(struct nodo *top){
  int pot = pow(top -> altezza,2);
  float ind = 0 ;
  ind = top -> peso/(long double) pot;
  return ind;
}


struct nodo *elimina (struct nodo *top){
  struct nodo *prev,*curr = top;
  while (curr != NULL && calcola_indice(curr) > 0.002500){
    prev = curr;
    curr = curr -> next;
    free(prev);
  }

  top = curr;
  if (top != NULL){
    prev = curr;
    curr = curr -> next;
    while(curr != NULL){
      if (calcola_indice(curr) > 0.002500){
        prev -> next = curr -> next;
        free (curr);
        curr = prev -> next;
      }else{
        prev = curr;
        curr = curr -> next;
      }
    }
  }
  return top;
}

struct nodo *inserisci2(struct nodo *top,struct nodo *top2){
  struct nodo *prev = NULL, *curr = top, *new;
  while (curr != NULL){
    prev = curr;
    curr = curr -> next;
  }
  new = malloc(sizeof(struct nodo));
  strcpy(new -> nome,top2 -> nome);
  strcpy(new -> cognome,top2 -> cognome);
  new -> peso = top2 -> peso;
  new -> altezza = top2 ->  altezza;
  new -> eta = top2 -> eta;

  if (prev == NULL){
    new -> next = top;
    top = new;
    return top;
  }else{
    prev -> next = new;
    new -> next = curr;
    return top;
  }
}

struct nodo *ordina(struct nodo *top){
  struct nodo *curr = top,*new;
  new = NULL;
  while (curr != NULL){
    if (curr -> peso >= 60){
      new = inserisci2(new,curr);
    }
    curr = curr -> next;
  }
  return new;
}

struct nodo *elimina2(struct nodo *top){
  struct nodo *prev,*curr = top;
  while (curr != NULL && curr -> peso >= 60){
    prev = curr;
    curr = curr -> next;
    free(prev);
  }

  top = curr;
  if (top != NULL){
    prev = curr;
    curr = curr -> next;
    while(curr != NULL){
      if (curr -> peso >= 60){
        prev -> next = curr -> next;
        free (curr);
        curr = prev -> next;
      }else{
        prev = curr;
        curr = curr -> next;
      }
    }
  }
  return top;
}


struct nodo *addiziona(struct nodo *top, struct nodo *aux){
  struct nodo *p=NULL,*curr;
  curr = top;
  while (curr != NULL){
    p = inserisci2(p,curr);
    curr = curr -> next;
  }
  curr = aux;
  while (curr != NULL){
    p = inserisci2(p,curr);
    curr = curr -> next;
  }
  return p;
}

void visualizza (struct nodo *top){
  struct nodo *p = top;
  while (p != NULL){
    printf("%s\t%s\t%d\t%d\t%d\n",p -> nome,p -> cognome,p -> peso,p -> altezza,p -> eta);
    p = p -> next;
  }
  printf("END\n");
}

int main(){
  struct nodo *top=NULL,*aux = NULL;
  char nome[max],cognome[max];
  int peso,altezza,eta;
  FILE *fp;
  fp = fopen("file.txt","r");
  fscanf(fp, "%s %s %d %d %d\n",nome,cognome,&peso,&altezza,&eta);
  while(!feof(fp)){
    top = inserisci_elementi(top,nome,cognome,peso,altezza,eta);
    fscanf(fp, "%s %s %d %d %d\n",nome,cognome,&peso,&altezza,&eta);
  }
  top = inserisci_elementi(top,nome,cognome,peso,altezza,eta);
  fclose(fp);
  printf("\n\n");
  top = elimina(top);
  aux = ordina(top);
  top = elimina2(top);
  top = addiziona(top,aux);
  fp = fopen("file2.txt","w");
  while(top != NULL){
    fprintf(fp, "%s %s %d %d %d\n",top -> nome,top -> cognome,top -> peso,top -> altezza,top -> eta);
    top = top -> next;
  }
  fclose(fp);
}
